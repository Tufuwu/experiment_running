#!/usr/bin/env python

type_dict = {}
bond_types=[]
angle_types=[]
dihedral_types=[]
bonds = False
angles = False
dihedrals = False
for line in open("topol.top"):
    ls=line.split()
    if len(ls)==11 and "Force" not in line:
        type_dict[ls[0]] = ls[1]
for line in open("topol.top"):
    ls=line.split()
    if "bonds" in line:
        bonds=True
    if bonds is True and '[' not in line:
        if len(ls)==3:
            bond_types.append(ls[0:2])
    elif "pairs" in line:
        bonds=False
    if "angles" in line:
        angles=True
    if angles is True and '[' not in line:
        if len(ls)==4: 
            angle_types.append(ls[0:3])
    elif "dihedrals" in line:
        angles=False
        dihedrals=True
    if dihedrals is True and '[' not in line:
        if len(ls)==5:
            dihedral_types.append(ls[0:4])
#for i in range(len(bond_types)):
#    bond_types[i][0] = type_dict[bond_types[i][0]]
#    bond_types[i][1] = type_dict[bond_types[i][1]]
#for i in range(len(angle_types)):
#    angle_types[i][0] = type_dict[angle_types[i][0]]
#    angle_types[i][1] = type_dict[angle_types[i][1]]
#    angle_types[i][2] = type_dict[angle_types[i][2]]
for i in range(len(dihedral_types)):
    dihedral_types[i][0] = type_dict[dihedral_types[i][0]]
    dihedral_types[i][1] = type_dict[dihedral_types[i][1]]
    dihedral_types[i][2] = type_dict[dihedral_types[i][2]]
    dihedral_types[i][3] = type_dict[dihedral_types[i][3]]
dihedrals=False
for line in open("/home/jstoppelman/codes/phosaa_forcebalance_all/forcefield/phosaa.itp"):
#    if "bondtypes" in line:
#        bonds=True
#    if "angletypes" in line:
#        angles=True
    if "dihedraltypes" in line:
        dihedrals=True
#    if bonds is True and '[' not in line:
#        for i in range(len(bond_types)):
#            if bond_types[i][0] in line and bond_types[i][1] in line:
#                print(bond_types[i][0], bond_types[i][1])
#                print(line)
#    if angles is True and '[' not in line:
#        for i in range(len(angle_types)):
#            if angle_types[i][0] in line and angle_types[i][1] in line and angle_types[i][2] in line:
#                print(angle_types[i][0], angle_types[i][1], angle_types[i][2])
#                print(line)
    if dihedrals is True:
        for i in range(len(dihedral_types)):
            if dihedral_types[i][0] in line or dihedral_types[i][1] in line or dihedral_types[i][2] in line or dihedral_types[i][3] in line:
                print(dihedral_types[i][0], dihedral_types[i][1], dihedral_types[i][2], dihedral_types[i][3])
                print(line)
#    elif "angletypes" in line:
#        bonds=False
#    elif "dihedraltypes" in line:
#        angles=False
